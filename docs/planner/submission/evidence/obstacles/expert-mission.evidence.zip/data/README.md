# Доказательства модельной миссии

Откройте report.html. Проверка из корня проекта: `node --experimental-transform-types scripts/verify-mission-archive.ts <archive.zip>`. Хеши не являются электронной подписью. Реальные БВС не подключены. Высоты KML находятся в ExtendedData; линия — проекция, не фиктивный AMSL.
